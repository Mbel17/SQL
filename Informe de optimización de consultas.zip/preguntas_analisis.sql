-- ¿Qué regiones han sido más afectadas por huracanes en los últimos 10 años?
SELECT
    r.NombreRegion,
    COUNT(e.EventoID) AS Numero_De_Huracanes
FROM
    Eventos AS e
JOIN
    Regiones AS r ON e.RegionID = r.RegionID
JOIN
    Tipos_Evento AS te ON e.TipoEventoID = te.TipoEventoID
WHERE
    te.NombreEvento = 'Huracán'
    AND e.FechaEvento >= CURDATE() - INTERVAL 10 YEAR
GROUP BY
    r.NombreRegion
ORDER BY
    Numero_De_Huracanes DESC;
    
-- ¿Qué tipo de fenómeno meteorológico tiene mayor frecuencia en cada región?
WITH FrecuenciaEventos AS (
    SELECT
        r.NombreRegion,
        te.NombreEvento,
        COUNT(e.EventoID) AS Frecuencia,
        ROW_NUMBER() OVER(PARTITION BY r.NombreRegion ORDER BY COUNT(e.EventoID) DESC) as Ranking
    FROM
        Eventos AS e
    JOIN
        Regiones AS r ON e.RegionID = r.RegionID
    JOIN
        Tipos_Evento AS te ON e.TipoEventoID = te.TipoEventoID
    GROUP BY
        r.NombreRegion,
        te.NombreEvento
)
SELECT
    NombreRegion,
    NombreEvento AS Fenomeno_Mas_Frecuente,
    Frecuencia
FROM
    FrecuenciaEventos
WHERE
    Ranking = 1;

-- ¿Qué meses del año presentan mayor incidencia de eventos extremos?
SELECT
    MONTHNAME(FechaEvento) AS Mes,
    COUNT(EventoID) AS Numero_De_Eventos
FROM
    Eventos
GROUP BY
    Mes,
    MONTH(FechaEvento)
ORDER BY
    Numero_De_Eventos DESC;






    