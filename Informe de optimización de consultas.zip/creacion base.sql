CREATE DATABASE IF NOT EXISTS Proyecto_final;

USE Proyecto_final;

-- Tabla 1: Catálogo de Regiones
CREATE TABLE Regiones (
    RegionID INT PRIMARY KEY AUTO_INCREMENT,
    NombreRegion VARCHAR(100) NOT NULL,
    Latitud DECIMAL(9, 6) NOT NULL,
    Longitud DECIMAL(9, 6) NOT NULL
);

-- Tabla 2: Catálogo de Tipos de Evento
CREATE TABLE Tipos_Evento (
    TipoEventoID INT PRIMARY KEY AUTO_INCREMENT,
    NombreEvento VARCHAR(50) NOT NULL UNIQUE
);

-- Tabla 3: Tabla principal de Eventos
CREATE TABLE Eventos (
    EventoID INT PRIMARY KEY AUTO_INCREMENT,
    TipoEventoID INT,
    Intensidad VARCHAR(50),
    DuracionEnHoras DECIMAL(10, 2),
    Impacto TEXT,
    RegionID INT,
    FechaEvento DATE,
    FOREIGN KEY (RegionID) REFERENCES Regiones(RegionID) ON DELETE CASCADE,
    FOREIGN KEY (TipoEventoID) REFERENCES Tipos_Evento(TipoEventoID) ON DELETE CASCADE
);

-- Tabla 4: Catálogo de Factores
CREATE TABLE Factores (
    FactorID INT PRIMARY KEY AUTO_INCREMENT,
    DescripcionFactor VARCHAR(100) NOT NULL UNIQUE
);

-- Tabla 5: Relación Evento-Factores
CREATE TABLE Evento_Factores (
    EventoID INT,
    FactorID INT,
    ValorNumerico DECIMAL(15, 4) NOT NULL,
    UnidadMedida VARCHAR(20),
    PRIMARY KEY (EventoID, FactorID),
    FOREIGN KEY (EventoID) REFERENCES Eventos(EventoID) ON DELETE CASCADE,
    FOREIGN KEY (FactorID) REFERENCES Factores(FactorID) ON DELETE CASCADE
);

-- Tabla 6: Catálogo de Tipos de Demografía
CREATE TABLE Tipos_Demografia (
    DemografiaID INT PRIMARY KEY AUTO_INCREMENT,
    DescripcionDemografica VARCHAR(100) NOT NULL UNIQUE
);

-- Tabla 7: Relación Región-Demografía
CREATE TABLE Region_Demografia (
    RegionID INT,
    DemografiaID INT,
    ValorNumerico DECIMAL(20, 2) NOT NULL,
    UnidadMedida VARCHAR(50),
    PRIMARY KEY (RegionID, DemografiaID),
    FOREIGN KEY (RegionID) REFERENCES Regiones(RegionID) ON DELETE CASCADE,
    FOREIGN KEY (DemografiaID) REFERENCES Tipos_Demografia(DemografiaID) ON DELETE CASCADE
);
