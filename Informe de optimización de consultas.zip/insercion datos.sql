USE Proyecto_final;

INSERT INTO Regiones (NombreRegion, Latitud, Longitud) VALUES
('Costa de Florida, USA', 25.7617, -80.1918),
('Ciudad de México, México', 19.4326, -99.1332),
('Región de Tōhoku, Japón', 38.2682, 140.8694),
('Nueva Orleans, USA', 29.9511, -90.0715),
('Región de Valdivia, Chile', -39.8142, -73.2459),
('Norte de California, USA', 38.5816, -121.4944);

INSERT INTO Tipos_Evento (NombreEvento) VALUES
('Huracán'),
('Terremoto'),
('Inundación'),
('Incendio Forestal');

INSERT INTO Factores (DescripcionFactor) VALUES
('Velocidad del Viento'),
('Magnitud Richter'),
('Precipitación Acumulada'),
('Área Afectada');

INSERT INTO Tipos_Demografia (DescripcionDemografica) VALUES
('Población Total'),
('Número de Hospitales'),
('Densidad de Población (hab/km²)');

INSERT INTO Eventos (TipoEventoID, RegionID, FechaEvento, Intensidad, DuracionEnHoras, Impacto) VALUES
(1, 1, '1992-08-24', 'Categoría 5', 36.0, 'Destrucción masiva de propiedades en el sur de Florida.'),
(2, 2, '1985-09-19', '8.1 MW', 0.5, 'Colapso de cientos de edificios y miles de muertes.'),
(2, 3, '2011-03-11', '9.1 MW', 1.0, 'Generó un tsunami devastador y el accidente nuclear de Fukushima.'),
(1, 4, '2005-08-29', 'Categoría 5', 72.0, 'Inundación catastrófica de la ciudad y una de las peores crisis humanitarias en USA.'),
(2, 5, '1960-05-22', '9.5 MW', 0.75, 'El terremoto más potente jamás registrado, provocó tsunamis a través del Pacífico.'),
(4, 6, '2020-08-16', 'Complejo de August', 1200.0, 'El mayor incendio forestal registrado en la historia de California.'),
(3, 1, '2024-06-12', 'Severa', 48.0, 'Inundaciones repentinas por lluvias torrenciales en Miami-Dade.'),
(1, 4, '2021-08-29', 'Categoría 4', 60.0, 'Daños graves a la infraestructura eléctrica y estructural.'),
(4, 6, '2018-11-08', 'Camp Fire', 720.0, 'El incendio más destructivo y mortal de la historia de California, destruyó la ciudad de Paradise.'),
(2, 3, '1995-01-17', '6.9 MW', 0.4, 'Gran terremoto de Hanshin que causó graves daños en la ciudad de Kobe.');

-- Datos demográficos para cada región
INSERT INTO Region_Demografia (RegionID, DemografiaID, ValorNumerico, UnidadMedida) VALUES
(1, 1, 6100000, 'habitantes'),
(1, 2, 58, 'unidades'),
(2, 1, 9200000, 'habitantes'),
(2, 2, 315, 'unidades'),
(3, 1, 9000000, 'habitantes'),
(3, 2, 180, 'unidades'),
(4, 1, 380000, 'habitantes'),
(4, 2, 15, 'unidades'),
(5, 1, 166000, 'habitantes'),
(5, 2, 8, 'unidades'),
(6, 1, 7000000, 'habitantes'),
(6, 2, 120, 'unidades');

INSERT INTO Evento_Factores (EventoID, FactorID, ValorNumerico, UnidadMedida) VALUES
(1, 1, 265, 'km/h'),     
(2, 2, 8.1, 'MW'),        
(3, 2, 9.1, 'MW'),         
(4, 1, 280, 'km/h'),       
(4, 3, 380, 'mm'),         
(5, 2, 9.5, 'MW'),         
(6, 4, 4170, 'km²'),       
(7, 3, 250, 'mm'),          
(8, 1, 240, 'km/h'),       
(9, 4, 620, 'km²'), 
(10, 2, 6.9, 'MW');       

